import Foundation

actor InboxStoreWorker {
    private var classificationCache: [String: InboxFilterEngine.CacheEntry] = [:]

    /// Compute inbox view state from EmailSnapshot value types.
    /// IMPORTANT: Takes EmailSnapshot (pure value type, Sendable) instead of Email (SwiftData model)
    /// to avoid cross-actor SwiftData access issues that cause main thread stalls.
    func computeState(
        emails: [EmailSnapshot],
        currentTab: InboxTab,
        pinnedTabOption: PinnedTabOption,
        activeFilter: InboxFilter?,
        currentAccountEmail: String?,
        searchFilter: SearchFilter?
    ) -> InboxViewState {
        let cacheResult = InboxFilterEngine.buildClassificationCache(
            emails: emails,
            existingCache: classificationCache,
            currentAccountEmail: currentAccountEmail
        )
        classificationCache = cacheResult.cache

        let filtered = InboxFilterEngine.applyFilters(
            emails,
            currentTab: currentTab,
            pinnedTabOption: pinnedTabOption,
            activeFilter: activeFilter,
            currentAccountEmail: currentAccountEmail,
            classifications: cacheResult.classifications
        )

        // Apply search filter (local search) if present
        let searchFiltered = searchFilter.map { filter in
            filtered.filter { filter.matches($0) }
        } ?? filtered

        let sections = InboxFilterEngine.groupEmailsByDate(searchFiltered)
        let counts = InboxFilterEngine.recomputeFilterCounts(
            from: emails,
            currentTab: currentTab,
            pinnedTabOption: pinnedTabOption,
            currentAccountEmail: currentAccountEmail,
            classifications: cacheResult.classifications
        )
        return InboxViewState(sections: sections, filterCounts: counts)
    }
}
