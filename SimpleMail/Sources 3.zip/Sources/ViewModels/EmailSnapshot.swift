import Foundation

struct EmailSnapshot: Sendable, Hashable {
    let id: String
    let date: Date
    let subject: String
    let snippet: String
    let senderEmail: String
    let senderName: String
    let isUnread: Bool
    let isStarred: Bool
    let accountEmail: String?
    let labelIdsKey: String
    let listUnsubscribe: String?
    let listId: String?
    let precedence: String?
    let autoSubmitted: String?
    let messagesCount: Int
}
