import Foundation

enum InboxTab: String, CaseIterable, Hashable {
    case all = "All"
    case primary = "Primary"
    case pinned = "Pinned"
}
