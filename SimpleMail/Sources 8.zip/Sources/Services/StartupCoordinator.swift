import Foundation
import SwiftData
import WebKit
import OSLog

private let startupLogger = Logger(subsystem: "com.simplemail.app", category: "StartupCoordinator")

@MainActor
final class StartupCoordinator {
    static let shared = StartupCoordinator()

    private var didStart = false
    private var didPreloadContacts = false

    private init() {}

    func start(modelContext: ModelContext, container: ModelContainer, isAuthenticated: Bool) {
        guard !didStart else { return }
        didStart = true

        // Stage 1: critical path (do synchronously so caches are ready before UI work)
        EmailCacheManager.shared.configure(with: modelContext, container: container, deferIndexRebuild: true)
        SnoozeManager.shared.configure(with: modelContext)
        OutboxManager.shared.configure(with: modelContext)
        NetworkMonitor.shared.start()

        // NOTE: WebKit warmup removed - warm on-demand when first opening EmailDetail
        // to avoid startup stalls.

        // Stage 2: Deferred search index warmup (after UI is responsive)
        // Use .utility priority and delay to avoid startup tax
        if isAuthenticated {
            Task.detached(priority: .utility) {
                // Wait for initial email list to finish rendering before warming search index
                try? await Task.sleep(for: .seconds(5))

                // Cancellation guard: get current account AFTER sleep
                // (user may have logged out or switched accounts during delay)
                guard let currentAccount = await MainActor.run(body: {
                    AuthService.shared.currentAccount?.email
                }) else {
                    startupLogger.debug("Search prewarm skipped - no current account")
                    return
                }

                await SearchIndexManager.shared.prewarmIfNeeded(accountEmail: currentAccount)
                startupLogger.info("Search index prewarmed for current account")
            }
        }
    }

    func handleAuthChanged(isAuthenticated: Bool) {
        if isAuthenticated { }
    }

    private func scheduleContactsPreloadIfNeeded(delaySeconds: Double) {
        guard !didPreloadContacts else { return }
        didPreloadContacts = true
        Task.detached(priority: .background) {
            if delaySeconds > 0 {
                try? await Task.sleep(for: .seconds(delaySeconds))
            }
            await PeopleService.shared.preloadContacts()
        }
    }
}
